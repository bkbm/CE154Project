<?php
//Registration Number: 1803522
Require ('ConnectDB.php');
if (!isset($_GET['delete_project_btn']) && empty($_GET['delete_project_btn'])){
	header('Location: ' . $_SERVER['HTTP_REFERER']);
	die();
}
$project = $_GET['project_id'];
$sql = "DELETE FROM task WHERE project_id = '$project';";
$query = mysqli_query($conn, $sql);
$sql = "DELETE FROM project WHERE id = '$project';";
$query = mysqli_query($conn, $sql);

if(!$query){
	echo "Error occurred: ". mysqli_error($conn);
}else{
	echo "Project successful";
}
header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
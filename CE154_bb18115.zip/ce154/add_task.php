<?php
//Registration Number: 1803522
Require ('ConnectDB.php');
if (!isset($_GET['create_task_btn']) && empty($_GET['create_task_btn'])){
	header('Location: ' . $_SERVER['HTTP_REFERER']);
	die();
}
if (empty($_GET['task_name'])||empty($_GET['deadline'])||empty($_GET['description'])||empty($_GET['priority'])||empty($_GET['project_id'])){
	header('Location: ' . $_SERVER['HTTP_REFERER']);
	die();
}

$sql = "INSERT INTO task VALUES (DEFAULT,'{$_GET['task_name']}','{$_GET['description']}','{$_GET['priority']}','{$_GET['deadline']}','{$_GET['project_id']}',0)";
$query = mysqli_query($conn, $sql);

if(!$query){
	echo "Error occurred: ". mysqli_error($conn);
}else{
	echo "Project successful";
}
header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
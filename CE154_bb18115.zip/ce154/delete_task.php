<?php
//Registration Number: 1803522
Require ('ConnectDB.php');
if (!isset($_GET['delete_task_btn']) && empty($_GET['delete_task_btn'])){
	header('Location: ' . $_SERVER['HTTP_REFERER']);
	die();
}
$project = $_GET['id'];
$sql = "DELETE FROM task WHERE id = '$project';";
$query = mysqli_query($conn, $sql);

if(!$query){
	echo "Error occurred: ". mysqli_error($conn);
}else{
	echo "Project successful";
}
header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
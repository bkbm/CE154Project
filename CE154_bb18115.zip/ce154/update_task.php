<?php
//Registration Number: 1803522
Require ('ConnectDB.php');
if (!isset($_GET['update_task_btn']) && empty($_GET['update_task_btn'])){
	header('Location: ' . $_SERVER['HTTP_REFERER']);
	die();
}
if (empty($_GET['task_name'])||empty($_GET['deadline'])||empty($_GET['description'])||empty($_GET['priority'])){
	header('Location: ' . $_SERVER['HTTP_REFERER']);
	die();
}

$sql = "UPDATE task SET title = '{$_GET['task_name']}', details='{$_GET['description']}', priority='{$_GET['priority']}',deadline='{$_GET['deadline']}', done={$_GET['isDone']} WHERE id = '{$_GET['id']}'";
$query = mysqli_query($conn, $sql);

if(!$query){
	echo "Error occurred: ". mysqli_error($conn);
}else{
	echo "Project successful";
}
header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
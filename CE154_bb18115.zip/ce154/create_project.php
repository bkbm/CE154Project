<?php
//Registration Number: 1803522
Require ('ConnectDB.php');
if (!isset($_GET['create_project_btn']) && empty($_GET['create_project_btn'])){
	header('Location: ' . $_SERVER['HTTP_REFERER']);
	die();
}
if (empty($_GET['project_name'])){
	header('Location: ' . $_SERVER['HTTP_REFERER']);
	die();
}

$project = $_GET['project_name'];
$sql = "INSERT INTO project VALUES (DEFAULT, '$project')";
$query = mysqli_query($conn, $sql);

if(!$query){
	echo "Error occurred: ". mysqli_error($conn);
}else{
	echo "Project successful";
}
header('Location: ' . $_SERVER['HTTP_REFERER']);
?>
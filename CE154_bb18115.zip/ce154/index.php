<?php
//Registration Number: 1803522
  Require ('ConnectDB.php');
function checkedColour($done){
	
	if ($done == 1){
	$style  = "background-color: rgba(0,255,180,0.5);";
	return $style;
	}
}
?>

<!DOCTYPE html>
<html lang="en-GB">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="height=device-height, width=device-width, initial-scale=1">
<title>Task Master</title>
<link rel="stylesheet" type="text/css" href="css/CE154CSS.css"/>
</head>
<body>
<div id= "Navigation" class="navigation" onmouseover="openNav()" onmouseout="closeNav()">
 <h2>Project</h2>
 <form id= "addProject" action="create_project.php" method="get">
   <input type="text" name= "project_name" autocomplete="off">
   <input type="submit" name="create_project_btn" value="Create Project">
 </form>
 <div class="buttonbox">
    <?php
    $sql = "SELECT id ,name FROM project;";
	$result = mysqli_query($conn, $sql);
	 if ($result){
		if(mysqli_num_rows($result)> 0){
			while($row = mysqli_fetch_assoc($result)) {
				echo '<div class= "project"><a class="button" href="index.php?project_id='.$row['id'].'">'.$row['name'].'</a>';
				echo '<form action="deleteproject.php" method="get">';
				echo '<input style="display:none;" type="text" name="project_id" value="'.$row['id'].'">';
				echo '<input class="delete" name="delete_project_btn" type="submit" value="x">';
				echo'</form></div>';
				}
			}
		 }
    ?>
 </div>
</div>
<div id="Main" class="main">
<div class="header">
  <a href="index.php"><h1>Task Master</h1></a>
</div>  
<div class="content">  
  
	<div class="list">
	<div style="margin-bottom:3px;">
	  <button class="addtask" id = "Add_task" onclick="return toggleContentHide(this);">Add Task</button>
	  <div class="taskContent">
	  <form action="add_task.php" method="get">
	    <div class="field" style="float: left;">
	      <label>Title</label>
	      <input type= "text" name="task_name" >	
	    </div>
		<div class="field" style="margin-left: 5px;">
		  <label>Deadline</label>
	      <input type= "date" name="deadline" >
		</div>
	  
	    <div class="field">
			<label>Description</label>
	        <input type= "text" name="description" >
	      </div>
		
		  <div class="field">
	        Priority: 
		    <select name="priority">
		    <option value="High">High</option>
			<option value="Medium">Medium</option>
			<option value="Low">Low</option>
		    </select>
	      </div>
		  <div class="field">
		  <input style="display:none;" type="text" name="project_id" value="<?php echo $_GET['project_id'];?>">
		  </div>
		  <div class="field">
		  <input class="" type="submit"  name="create_task_btn" value="Create Task" >
		  </div>
	    </form>
	  </div>
	</div>
	  <div style="height : 2px;">
	  
	  <?php
	    if(isset($_GET['project_id'])){
			$sql = "SELECT * FROM task WHERE project_id = '{$_GET['project_id']}' ORDER BY deadline;";
		}else{
			$sql = "SELECT * FROM task ORDER BY deadline;";
		}
		$result = mysqli_query($conn, $sql);
	    if ($result){
			if(mysqli_num_rows($result)> 0){
				while($row = mysqli_fetch_assoc($result)) {
					echo '<div><button  style="'.checkedColour($row['done']).'" class="row" id = "task" onclick="return toggleContentHide(this);">'.$row['title'].'</button>';
					echo '<div class="taskContent">';
					echo '<form action="update_task.php" method="get">';
					echo '<div class="field" style="float: left;">';
					echo '<label>Title</label>';
					echo '<input type= "text" name="task_name" value="'.$row['title'].'" >';	
					echo '</div>';
					echo '<div class="field" style="margin-left: 5px;">';
					echo '<label>Deadline</label>';
					echo '<input type= "date" name="deadline" value="'.$row['deadline'].'">';
					echo '</div>';	  
					echo '<div class="field">';
					echo '<label>Description</label>';
					echo '<input type= "text" name="description" value="'.$row['details'].'" >';
	                echo '</div>';		
					echo '<div class="field">';
					echo 'Priority:'; 
					echo '<select name="priority" value="'.$row['priority'].'">';
					echo '<option value="High">High</option>';
					echo '<option value="Medium">Medium</option>';
					echo '<option value="Low">Low</option>';
					echo '</select>';
					echo '</div>';
					echo '<div class="field">';
					echo '<input class="" type="hidden"  name="isDone" value="0" />';
					echo '<input class="" type="checkbox"  name="isDone" value="1" />';
					echo '<input class="" type="hidden"  name="id" value="'.$row['id'].'" />';
					echo '</div>';
					echo '<div class="field">';
					echo '<input class="" type="submit"  name="update_task_btn" value="Update Task" >';
					echo '</div>';
					echo '</form>';
					echo '<div><form action="delete_task.php" method="get">';
					echo '<input type="text" style="display:none;" name="id" value="'.$row['id'].'">';
					echo '<input type="submit" name="delete_task_btn" value="Delete Task">';
					echo '</form></div>';
					
					echo '</div>';
					echo '</div>';
				}
			}
		 }		
	  ?>
	</div>
</div>
</div>
<div class=footer>
Reference:
<p><a href="https://www.w3schools.com/howto/howto_js_off-canvas.asp"> Used parts styling in this tutorial to use as a base for my navigation bar:  https://www.w3schools.com/howto/howto_js_off-canvas.asp</a></p>
<p><a href="https://www.w3schools.com/howto/howto_js_collapsible.asp"> Used W3schools collapsible how-to to create the collapsible task details and hide the create a project form when the navigation is closed:  https://www.w3schools.com/howto/howto_js_collapsible.asp</a></p>
<p><a href="https://www.youtube.com/watch?v=sND7a3k5yts"> Used parts of walkthrough in the structure of my database, writing a form and connecting to the database from the web page:  https://www.youtube.com/watch?v=sND7a3k5yts</a></p>
<p><a href="https://www.w3schools.com/css/css_image_transparency.asp"> Used to style the boxes to make them slightly transparent:  https://www.w3schools.com/css/css_image_transparency.asp</a></p>
</div>
</div>

<script>
function openNav(){
  document.getElementById("Navigation").style.width = "10%";
  document.getElementById("Main").style.marginLeft = "10%";
  document.getElementById("addProject").style.height = "auto";
  document.getElementById("addProject").style.display = "block";
}
function closeNav() {
  document.getElementById("Navigation").style.width = "0.5%";
  document.getElementById("Main").style.marginLeft= "0.5%";
  document.getElementById("addProject").style.height = "0%";
  document.getElementById("addProject").style.display = "none";
}
function toggleContentHide(id) {
  var content = id.nextElementSibling;
  if (id.id.includes("active")){
	content.style.display = "none";
	id.id = id.id.replace("active","");
  }
  else{
	content.style.display = "block";
	id.id = "active"+id.id;
  }
}
function today(){
	var date = new Date();
}
	id = document.getElementById("addProject");
	id.style.transition= "height 1s";
	id.style.display = "none";
	id.style.height = "0%";
</script>
</body>
</html>